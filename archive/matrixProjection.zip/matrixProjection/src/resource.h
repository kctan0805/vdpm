//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by matrixProjection.rc
//
#define IDD_FORMVIEW                    101
#define IDR_MENU_MAIN                   101
#define IDD_ABOUT                       102
#define IDB_BITMAP1                     103
#define IDB_SONGHO                      103
#define IDC_RADIO_PERSPECTIVE           1001
#define IDC_RADIO_ORTHO                 1002
#define IDC_EDIT_LEFT                   1003
#define IDC_EDIT_RIGHT                  1004
#define IDC_EDIT_BOTTOM                 1005
#define IDC_EDIT_TOP                    1006
#define IDC_EDIT_NEAR                   1007
#define IDC_EDIT_FAR                    1008
#define IDC_BUTTON_RESET                1009
#define IDC_SPIN_LEFT                   1010
#define IDC_SPIN_RIGHT                  1011
#define IDC_SPIN_BOTTOM                 1012
#define IDC_SPIN_TOP                    1013
#define IDC_SPIN_NEAR                   1014
#define IDC_SPIN_FAR                    1015
#define IDC_M0                          1016
#define IDC_GL                          1017
#define IDC_M1                          1018
#define IDC_OK                          1018
#define IDC_M2                          1019
#define IDC_M3                          1020
#define IDC_M4                          1021
#define IDC_M5                          1022
#define IDC_M6                          1023
#define IDC_M7                          1024
#define IDC_M8                          1025
#define IDC_M9                          1026
#define IDC_M10                         1027
#define IDC_M11                         1028
#define IDC_M12                         1029
#define IDC_M13                         1030
#define IDC_M14                         1031
#define IDC_M15                         1032
#define IDC_RADIO_FILL                  1033
#define IDC_RADIO_LINE                  1034
#define IDC_RADIO_POINT                 1035
#define ID_FILE_EXIT                    40001
#define ID_HELP_ABOUT                   40002

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40003
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
