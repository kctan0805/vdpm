Loaders
=======
A *Loader* is a plugin that reads a particular file type and transforms it
into an osgEarth object or set of objects.

.. toctree::
   :maxdepth: 1

   earth
   kml
