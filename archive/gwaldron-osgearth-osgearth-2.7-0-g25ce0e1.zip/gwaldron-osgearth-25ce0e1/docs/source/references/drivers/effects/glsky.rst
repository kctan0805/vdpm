GL Sky
======
Sky model that implements OpenGL Phong shading.

Example usage::

    <map>
        <options>
            <sky driver  = "gl"
			     hours   = "0.0"
                 ambient = "0.05" />

   
.. include:: sky_shared.rst
