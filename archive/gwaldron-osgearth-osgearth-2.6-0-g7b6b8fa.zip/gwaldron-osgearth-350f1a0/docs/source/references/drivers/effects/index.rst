Effects Drivers
===============
Plugins that implement special effects.

.. toctree::
   :maxdepth: 1

   glsky
   simplesky
   silverlining