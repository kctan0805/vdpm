Common Properties:

    :hours:     Time of day; UTC hours [0..24]
    :ambient:   Minimum ambient lighting level [0..1] to apply to dark areas of the terrain
