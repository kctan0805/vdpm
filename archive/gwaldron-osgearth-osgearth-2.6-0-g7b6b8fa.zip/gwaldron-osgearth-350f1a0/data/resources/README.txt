LICENSE
Everything in this folder (data/resources) is in the PUBLIC DOMAIN.
