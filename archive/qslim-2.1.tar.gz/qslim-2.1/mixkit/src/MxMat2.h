#ifndef MXMAT2_INCLUDED // -*- C++ -*-
#define MXMAT2_INCLUDED
#if !defined(__GNUC__)
#  pragma once
#endif

/************************************************************************

  2x2 Matrix class

  Copyright (C) 1998 Michael Garland.  See "COPYING.txt" for details.
  
  $Id: MxMat2.h,v 1.10 2000/11/20 20:36:38 garland Exp $

 ************************************************************************/

#include <gfx/mat2.h>

// MXMAT2_INCLUDED
#endif
