/************************************************************************

  Handy 4D geometrical primitives

  $Id: geom4d.cxx 427 2004-09-27 04:45:31Z garland $

 ************************************************************************/

#include <gfx/gfx.h>
#include <gfx/geom4d.h>

namespace gfx
{
}
