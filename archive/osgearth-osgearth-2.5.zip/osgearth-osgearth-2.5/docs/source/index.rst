.. osgEarth documentation master file, created by
   sphinx-quickstart on Tue Jan  8 16:20:40 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

osgEarth - a C++ Terrain SDK
============================
Welcome to the osgEarth_ documentation project!

osgEarth_ is a big SDK. Keeping up on the documentation is not easy!
So now we've moved the docs right into the osgEarth Git repository to make
it easier for the osgEarth team and user community to help. Check the
links at the bottom of the sidebar.

Table of Contents
-----------------

.. toctree::
   :maxdepth: 2

   about
   startup
   user/index
   developer/index
   data
   howto
   references/index
   faq
   releasenotes


.. _osgEarth: http://osgearth.org
.. _GitHub:   http://github.com/gwaldron/osgearth
