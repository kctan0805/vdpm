//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by glWin.rc
//
#define IDD_CONTROLS                    101
#define IDS_APP_NAME                    101
#define IDR_MAIN_MENU                   102
#define IDC_ANIMATE                     1001
#define IDC_WIREFRAME                   1002
#define IDC_FILL                        1003
#define IDC_RADIO3                      1005
#define IDC_POINT                       1005
#define IDC_RED                         1007
#define IDC_GREEN                       1008
#define IDC_BLUE                        1009
#define IDC_STATUSBAR                   1010
#define ID_FILE_EXIT                    40001

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40002
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
